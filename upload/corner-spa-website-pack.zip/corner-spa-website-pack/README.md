# Corner Spa website pack

Contains the reviews carousel and the Black Friday pop-up.

## What's inside
- `demo.html`: working example. Double-click to preview in a browser.
- `css/` and `js/`: carousel and pop-up code (no libraries needed).
- `images/reviews/`: the 7 reviews, cropped, sharpened, same dark background and gold frame.
- `images/reviews-clean/`: same reviews on plain white, no frame (spare).
- `images/black-friday-special.jpg`: the pop-up poster.

## 1. Upload
Upload the whole folder to your website, keeping the folder structure
(`css`, `js`, `images` next to each other). If your site already has these folders, merge them.

## 2. Reviews page (carousel)
1. In the `<head>` of the reviews page add:
   `<link rel="stylesheet" href="css/reviews-carousel.css">`
2. Where the reviews should appear, paste the `<section class="cs-reviews"> ... </section>` block from `demo.html`.
3. Just before `</body>` add: `<script src="js/reviews-carousel.js"></script>`

To add a new review later: process the photo, save it as `images/reviews/review-8.jpg`, then copy one
`<figure class="cs-reviews__slide">` line and change the image name and description (alt text).

It swipes on phones, has arrows on desktop, and auto-plays every 5 seconds (stops when touched or hovered).

## 3. Black Friday pop-up
1. In the `<head>` of every page that should show it add:
   `<link rel="stylesheet" href="css/black-friday-popup.css">`
2. Just before `</body>` add: `<script src="js/black-friday-popup.js"></script>`

Open `js/black-friday-popup.js` and edit the SETTINGS at the top:
- `START` / `END`: dates it shows (currently 16 to 30 Nov 2026, it switches itself off after).
- `DELAY_MS`: seconds before it appears (1500 = 1.5 seconds).
- `WHATSAPP`: booking link (set to +264 81 623 4788).
- `IMAGE`: poster path. Use an absolute path like `/images/black-friday-special.jpg` if your pages sit in sub-folders.

It shows once per visit, closes with the X, Esc, or by tapping outside, and tapping "Book on WhatsApp" opens WhatsApp.
To test it again, close the browser tab and reopen.

## WordPress / Wix / Squarespace
Upload the images to the media library, then paste the carousel block into a "Custom HTML" block.
Put the CSS in the theme's "Additional CSS" and the two JS files in "Custom code" (footer). Update the
image paths to the uploaded URLs.
