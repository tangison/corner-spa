/* Corner Spa – Black Friday pop-up (no dependencies) */
(function(){
  /* ---- SETTINGS: change these ---- */
  var IMAGE   = 'images/black-friday-special.jpg'; // path to the poster
  var WHATSAPP= 'https://wa.me/264816234788';      // booking link
  var START   = '2026-11-16';                      // first day to show
  var END     = '2026-11-30';                      // last day to show
  var DELAY_MS= 1500;                              // wait before showing
  /* -------------------------------- */
  var today=new Date().toISOString().slice(0,10);
  if(today<START||today>END)return;
  try{if(sessionStorage.getItem('cs-bf-seen'))return}catch(e){}
  var box=document.createElement('div');
  box.className='cs-bf';box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');box.setAttribute('aria-label','Black Friday Special');
  box.innerHTML='<div class="cs-bf__dialog"><img class="cs-bf__img" src="'+IMAGE+'" alt="Corner Spa Black Friday Special: full body massage from N$150, waxing, foot spa N$200. Book on WhatsApp +264 81 623 4788">'+
    '<a class="cs-bf__book" href="'+WHATSAPP+'" target="_blank" rel="noopener" aria-label="Book on WhatsApp"></a>'+
    '<button class="cs-bf__close" type="button" aria-label="Close">&times;</button></div>';
  document.body.appendChild(box);
  var last=null;
  function close(){box.classList.remove('is-open');try{sessionStorage.setItem('cs-bf-seen','1')}catch(e){}if(last)last.focus()}
  box.addEventListener('click',function(e){if(e.target===box)close()});
  box.querySelector('.cs-bf__close').addEventListener('click',close);
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&box.classList.contains('is-open'))close()});
  setTimeout(function(){last=document.activeElement;box.classList.add('is-open');box.querySelector('.cs-bf__close').focus()},DELAY_MS);
})();
