/* Corner Spa – reviews carousel (no dependencies) */
(function(){
  document.querySelectorAll('[data-cs-reviews]').forEach(function(root){
    var track=root.querySelector('.cs-reviews__track');
    var slides=[].slice.call(track.children);
    var dotsBox=root.querySelector('.cs-reviews__dots');
    var timer=null, AUTOPLAY_MS=5000;
    slides.forEach(function(_,i){
      var b=document.createElement('button');
      b.className='cs-reviews__dot';b.type='button';b.setAttribute('aria-label','Go to review '+(i+1));
      b.addEventListener('click',function(){go(i)});dotsBox.appendChild(b);
    });
    var dots=[].slice.call(dotsBox.children);
    function current(){
      var mid=track.scrollLeft+track.clientWidth/2,best=0,d=1e9;
      slides.forEach(function(s,i){var c=Math.abs(s.offsetLeft+s.offsetWidth/2-mid);if(c<d){d=c;best=i}});
      return best;
    }
    function go(i){
      i=(i+slides.length)%slides.length;var s=slides[i];
      track.scrollTo({left:s.offsetLeft-(track.clientWidth-s.offsetWidth)/2,behavior:'smooth'});
    }
    function mark(){var c=current();dots.forEach(function(d,i){d.setAttribute('aria-current',i===c)})}
    track.addEventListener('scroll',function(){window.requestAnimationFrame(mark)});
    root.querySelector('.cs-reviews__prev').addEventListener('click',function(){go(current()-1)});
    root.querySelector('.cs-reviews__next').addEventListener('click',function(){go(current()+1)});
    function start(){
      if(window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
      stop();timer=setInterval(function(){go(current()+1)},AUTOPLAY_MS);
    }
    function stop(){if(timer){clearInterval(timer);timer=null}}
    ['mouseenter','focusin','touchstart'].forEach(function(e){root.addEventListener(e,stop,{passive:true})});
    ['mouseleave','focusout'].forEach(function(e){root.addEventListener(e,start)});
    mark();start();
  });
})();
